from typing import TYPE_CHECKING
from single_room import Room

if TYPE_CHECKING:
    from client import ClientThread

class Rooms:
    NOT_CONNECTED_TO_ROOM = -1

    def __init__(self) -> None:
        self.rooms_list: dict[int: Room] = dict()

    def add_client(self, room_id: int, client: 'ClientThread') -> bool:
        if room_id not in self.rooms_list:
            return False
        self.rooms_list[room_id].add_client(client)
        return True

    def remove_client(self, room_id: int, client: 'ClientThread') -> 'ClientThread':
        if client.room_id == self.NOT_CONNECTED_TO_ROOM:
            return None

        room_connected_to = self.rooms_list.get(room_id)

        if (len(room_connected_to.get_client_list()) == 1):
            self.rooms_list.pop(client.room_id)
            return None
        
        else:
            room_manager = room_connected_to.get_room_manager()
            room_connected_to.remove_client(client)
            
            if (client == room_manager):
                return room_connected_to.get_room_manager()
            return None

    
    def create_new_room(self, manager: 'ClientThread') -> int:
        if len(self.rooms_list) == 0:
            new_room_id = 0
        else:
            new_room_id = list(self.rooms_list.keys())[-1] + 1

        self.rooms_list[new_room_id] = Room(manager)

        return new_room_id
    
    def is_manager(self, client: 'ClientThread') -> bool:
        return client == self.rooms_list.get(client.room_id).get_client_list()[0]
    
    def get_room_client_list(self, room_id: int) -> list['ClientThread']:
        return self.rooms_list.get(room_id).get_client_list()
    
    def choose_word_for_round(self, room_id: int) -> str:
        return self.rooms_list.get(room_id).generate_secret_word()
    
    def get_secret_word(self, room_id: int) -> str:
        return self.rooms_list.get(room_id).get_secret_word()
    
    def get_users_json(self, room_id: int) -> str:
        return self.rooms_list.get(room_id).get_users_json()
    
    def room_exists(self, room_id: int) -> bool:
        return self.rooms_list.get(room_id) != None

    def is_room_ingame(self, room_id: int) -> bool:
        return self.rooms_list.get(room_id).is_ingame()
    
    def set_room_ingame(self, room_id: int, is_ingame: bool) -> None:
        self.rooms_list.get(room_id).set_ingame(is_ingame)