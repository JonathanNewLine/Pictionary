package com.example.pictionary;

import android.os.Bundle;

public class Settings extends BaseMainActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        findViewById(R.id.exit).setOnClickListener(v -> finish());

        findViewById(R.id.statistics).setOnClickListener(v -> {
            finish();
            goToStatisticsActivity(this);
        });

        findViewById(R.id.settings).setOnClickListener(v -> {
            finish();
            goToSettingsActivity(this);
        });


    }

}
