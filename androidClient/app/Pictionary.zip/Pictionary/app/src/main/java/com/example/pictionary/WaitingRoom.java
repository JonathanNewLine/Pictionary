package com.example.pictionary;

import static com.example.pictionary.DrawingScreen.DOUBLE_BACK_PRESS_INTERVAL;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.concurrent.CompletableFuture;

public class WaitingRoom extends BaseGameActivity {
    private Client client;
    private int gameId;
    private Button startGameBtn;
    private ImageView startGameIcon;
    private ListView usersListView;
    private boolean isManager;
    private UserAdapter userAdapter;
    private int backButtonCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_waiting_room);
        gameId = getIntent().getIntExtra("gameId", -1);
        client = Client.getInstance();
        startGameBtn = findViewById(R.id.start_game);
        startGameIcon = findViewById(R.id.start_game_icon);

        isManager = getIntent().getBooleanExtra("isManager", false);
        updateManagerScreen(isManager);

        usersListView = findViewById(R.id.side_users_list_view);
        userAdapter = new UserAdapter(this, 0, 0);
        usersListView.setAdapter(userAdapter);

        startGameBtn.setOnClickListener(v -> client.startGame());
        findViewById(R.id.invite_friends).setOnClickListener(this::inflateInvitationDialog);
        findViewById(R.id.exit).setOnClickListener(v -> exit(this, client));
        findViewById(R.id.open_users_side_bar).setOnClickListener(v ->
                showHideUsersSideBar(findViewById(R.id.users_side_bar)));

        overrideBackButton();

        listenForServer();

    }

    private void overrideBackButton() {
        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (backButtonCount >= 1) {
                    exit(WaitingRoom.this, client);
                }
                else {
                    Toast.makeText(WaitingRoom.this, "Press back again to exit", Toast.LENGTH_SHORT).show();
                    backButtonCount++;
                    new Handler().postDelayed(() -> backButtonCount = 0, DOUBLE_BACK_PRESS_INTERVAL);
                }
            }

        };
        getOnBackPressedDispatcher().addCallback(this, callback);
    }

    private void listenForServer() {
        CompletableFuture<Boolean> future = new CompletableFuture<>();
        client.receiveMessage().thenAccept(response -> runOnUiThread(()->{
            if (response.equals("start")) {
                if (!isManager) {
                    client.sendMessage("start ok");
                }
                Intent intent = new Intent(WaitingRoom.this, DrawingScreen.class);
                intent.putExtra("flag", isManager);
                startActivity(intent);
                finish();
                future.complete(false);
                return;
            }
            else if (response.equals("manager")) {
                isManager = true;
                updateManagerScreen(true);
                client.sendMessage("manager ok");
                future.complete(true);
            }
            else if (response.startsWith("users:")) {
                updateUsersSideBar(response, userAdapter);
            }
            else if (response.equals("exit ok")) {
                return;
            }
            listenForServer();
        }));
    }

    @SuppressLint("SetTextI18n")
    private void inflateInvitationDialog(View v) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.invite_friends, null);
        dialogBuilder.setView(dialogView);
        dialogBuilder.setCancelable(true);

        TextView gameIdTv = dialogView.findViewById(R.id.game_id);
        gameIdTv.setText(gameIdTv.getText().toString() + gameId);

        Dialog dialog = dialogBuilder.create();
        Window window = dialog.getWindow();
        assert window != null;
        WindowManager.LayoutParams wlp = window.getAttributes();
        wlp.gravity = Gravity.TOP;
        wlp.flags &= ~WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        window.setAttributes(wlp);
        dialog.show();
    }

    private void updateManagerScreen(boolean isManager) {
        if (isManager) {
            startGameBtn.setVisibility(View.VISIBLE);
            startGameIcon.setVisibility(View.VISIBLE);
        }
        else {
            startGameBtn.setVisibility(View.GONE);
            startGameIcon.setVisibility(View.GONE);
        }
    }
}