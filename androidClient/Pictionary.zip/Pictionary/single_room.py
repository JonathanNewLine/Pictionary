from typing import TYPE_CHECKING
import random
import json

if TYPE_CHECKING:
    from client import ClientThread

class Room:

    def __init__(self, manager: 'ClientThread') -> None:
        self.players: list['ClientThread'] = list()
        self.secret_word: str = ""
        self.ingame: bool = False
        self.room_start_time: str
        self.players.append(manager)
    
    def add_client(self, client: 'ClientThread') -> None:
        self.players.append(client)

    def remove_client(self, client: 'ClientThread') -> None:
        self.players.remove(client)

    def get_client_list(self) -> list['ClientThread']:
        return self.players
    
    def generate_secret_word(self) -> str:
        with open('word_list.json', 'r') as file:
            data = json.load(file)
        words = [entry['word'] for entry in data]
        self.secret_word = random.choice(words)
        return self.secret_word
    
    def get_room_manager(self) -> 'ClientThread':
        return self.players[0]
    
    def get_secret_word(self) -> str:
        return self.secret_word
    
    def get_users_json(self) -> str:
        client_data = []
        for client_thread in self.players:
            client_info = {
                "username": client_thread.name,
                "points": client_thread.points
            }
            client_data.append(client_info)
        return json.dumps(client_data)
    
    def is_ingame(self) -> bool:
        return self.ingame
    
    def set_ingame(self, is_ingame: bool) -> None:
        self.ingame = is_ingame

    def set_room_start_time(self, room_start_time: str) -> None:
        self.room_start_time = room_start_time

    def get_room_start_time(self) -> str:
        return self.room_start_time