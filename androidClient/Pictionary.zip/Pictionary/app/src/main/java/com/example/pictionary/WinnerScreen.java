package com.example.pictionary;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;

public class WinnerScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_winner_screen);

        ImageView exitWinnerScreen = findViewById(R.id.back_to_waiting_room);
        exitWinnerScreen.setOnClickListener(v -> finish());

    }
}