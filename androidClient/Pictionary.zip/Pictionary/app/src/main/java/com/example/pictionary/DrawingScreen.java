package com.example.pictionary;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.graphics.BitmapFactory;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.skydoves.colorpickerview.listeners.ColorEnvelopeListener;
import java.util.concurrent.ExecutionException;

public class DrawingScreen extends BaseGameActivity {
    private DrawOnView paintClass;
    private ImageView colorPalette;
    private Client client;
    private FrameLayout drawing_screen;
    private ImageView guesserImageView;
    private ImageView clearBtn;
    private ImageView undoBtn;
    private ImageView submitGuess;
    private EditText guesserToolbar;
    private TextView hint;
    private int backButtonCount = 0;
    private boolean isManager;
    private ListView usersListView;
    public static final int DOUBLE_BACK_PRESS_INTERVAL = 1000;
    private String correctGuess;
    private UserAdapter userAdapter;
    private com.skydoves.colorpickerview.ColorPickerView colorPickerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drawing_screen);

        client = Client.getInstance();

        drawing_screen = findViewById(R.id.drawing_screen);
        paintClass = new DrawOnView(this);

        submitGuess = findViewById(R.id.submit_guess);
        guesserImageView = findViewById(R.id.guesser_image_view);
        clearBtn = findViewById(R.id.clear);
        undoBtn = findViewById(R.id.undo);
        colorPalette = findViewById(R.id.color_palette);
        clearBtn.setOnClickListener(v -> paintClass.clear());
        undoBtn.setOnClickListener(v -> paintClass.undo());
        colorPalette.setOnClickListener(this::pickColor);
        guesserToolbar = findViewById(R.id.player_guess);
        colorPickerView = findViewById(R.id.colorPickerView);
        hint = findViewById(R.id.hint);

        usersListView = findViewById(R.id.side_users_list_view);
        userAdapter = new UserAdapter(this, 0, 0);
        usersListView.setAdapter(userAdapter);

        findViewById(R.id.exit).setOnClickListener(v -> exit(this, client));
        findViewById(R.id.open_users_side_bar).setOnClickListener(v ->
                showHideUsersSideBar(findViewById(R.id.users_side_bar)));

        isManager = getIntent().getBooleanExtra("flag", false);

        submitGuess.setOnClickListener(v -> {
            correctGuess = guesserToolbar.getText().toString();
            client.sendMessage(guesserToolbar.getText().toString());
            guesserToolbar.setText("");
        });

        if(!isManager) {
            getAppropriateToolBar(false);
            listenForServerNoneDrawer();
        }
        else {
            drawing_screen.addView(paintClass);
            getAppropriateToolBar(true);
            listenForServerDrawer();
        }

        overrideBackButton();
    }

    private void overrideBackButton() {
        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (backButtonCount >= 1) {
                    exit(DrawingScreen.this, client);
                }
                else {
                    Toast.makeText(DrawingScreen.this, "Press back again to exit", Toast.LENGTH_SHORT).show();
                    backButtonCount++;
                    new Handler().postDelayed(() -> backButtonCount = 0, DOUBLE_BACK_PRESS_INTERVAL);
                }
            }

        };
        getOnBackPressedDispatcher().addCallback(this, callback);
    }

    private void listenForServerDrawer() {
        client.receiveMessage().thenAccept(message -> runOnUiThread(() -> {
            if (message.equals("exit ok")) {
                return;
            }
            else if (message.equals("manager")) {
                isManager = true;
            }
            else if (message.startsWith("users:")) {
                updateUsersSideBar(message, userAdapter);
            }
            else {
                hint.setText(message);
            }
            listenForServerDrawer();
        }));
    }

    private void listenForServerNoneDrawer() {
        client.receiveMessage().thenAccept(message -> runOnUiThread(() -> {
            if (message.equals("exit ok")) {
                return;
            }
            else if (message.equals("manager")) {
                isManager = true;
                Toast.makeText(DrawingScreen.this, "you're the manager", Toast.LENGTH_SHORT).show();
            }
            else if (message.equals("correct")) {
                updateCorrectGuess();
            }
            else if (message.startsWith("users:")) {
                updateUsersSideBar(message, userAdapter);
            }
            else if (message.startsWith("clue:")) {
                hint.setText(message.split("clue: ")[1]);
            }
            else {
                String encodedBitmap;
                try {
                    encodedBitmap = client.receiveAll(message);
                } catch (ExecutionException | InterruptedException e) {
                    throw new RuntimeException(e);
                }
                byte[] bitmapBytes = client.transformToBitmap(encodedBitmap);
                runOnUiThread(() -> {
                    if (bitmapBytes != null) {
                        putBitmapOnImage(bitmapBytes);
                    }
                });
            }
            listenForServerNoneDrawer();
        }));
    }

    private void updateCorrectGuess() {
        findViewById(R.id.tool_bars).setBackgroundColor(Color.parseColor("#B5189501"));
        ((EditText)guesserToolbar).setEnabled(false);
        guesserToolbar.setFocusable(false);
        hint.setText(correctGuess);
    }

    private void putBitmapOnImage(byte[] bitmapBytes) {
        Bitmap bitmap = BitmapFactory.decodeByteArray(bitmapBytes, 0, bitmapBytes.length);
        guesserImageView.setImageBitmap(bitmap);
    }

    private void pickColor(final View view) {
        colorPickerView.setColorListener((ColorEnvelopeListener) (envelope, fromUser) -> {
            colorPalette.setColorFilter(envelope.getColor());
            paintClass.setColor(envelope.getColor());
        });
        if (colorPickerView.getVisibility() == View.GONE) {
            colorPickerView.setVisibility(View.VISIBLE);
        }
        else if (colorPickerView.getVisibility() == View.VISIBLE) {
            colorPickerView.setVisibility(View.GONE);
        }
    }

    private void getAppropriateToolBar(boolean isDrawer) {
        View drawerToolBar = findViewById(R.id.drawer_tool_bar);

        if (isDrawer) {
            submitGuess.setVisibility(View.GONE);
            guesserImageView.setVisibility(View.GONE);
            drawerToolBar.setVisibility(View.VISIBLE);
            guesserToolbar.setVisibility(View.GONE);
        }
        else {
            submitGuess.setVisibility(View.VISIBLE);
            guesserImageView.setVisibility(View.VISIBLE);
            drawerToolBar.setVisibility(View.GONE);
            guesserToolbar.setVisibility(View.VISIBLE);
        }
    }
}