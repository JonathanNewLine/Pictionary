package com.example.pictionary;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class BaseGameActivity extends AppCompatActivity {
    protected FirebaseAuth mAuth = FirebaseAuth.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onStart() {
        super.onStart();
        TextView loggedAs = findViewById(R.id.logged_as_game);
        FirebaseUser user = mAuth.getCurrentUser();

        if (user == null) {

            loggedAs.setText("Logged in as:\nguest");
        }

        FirebaseFirestore database = FirebaseFirestore.getInstance();
        CollectionReference usersTable = database.collection("users");
        assert user != null;
        usersTable.document(user.getUid()).get().addOnSuccessListener(documentSnapshot -> {
            DatabaseUser databaseUser = documentSnapshot.toObject(DatabaseUser.class);
            assert databaseUser != null;

            loggedAs.setText("Logged in as:\n" + databaseUser.getUsername());
        });
    }

    public void exit(Activity activity, Client client) {
        client.exitRoom();
        activity.finish();
    }

    public void showHideUsersSideBar(View sideBar) {
        if(sideBar.getVisibility() == View.VISIBLE) {
            sideBar.setVisibility(View.GONE);
        } else {
            sideBar.setVisibility(View.VISIBLE);
        }
    }

    public void updateUsersSideBar(String format, UserAdapter userAdapter) {
        ArrayList<User> usersConnectedToRoom = Client.getUsersList(format.split("users: ")[1]);
        userAdapter.clear();
        userAdapter.addAll(usersConnectedToRoom);
    }
}