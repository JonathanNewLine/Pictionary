import socket
from threading import Thread
from rooms import Rooms

BUFFER_SIZE = 1024 

class ClientThread(Thread):
    _id = 0

    @classmethod
    def id_generator(self) -> int:
        self._id += 1
        return self._id

    def __init__(self, ip: str, port: int, connection: socket, rooms: Rooms) -> None: 
        Thread.__init__(self)
        self.rooms = rooms
        self.ip = ip
        self.port = port
        self.connection = connection
        self.name = "Matan Cool"
        self.points = 0
        self.id = self.id_generator()
        self.is_drawing = (self.id == 1)
        self.room_id = Rooms.NOT_CONNECTED_TO_ROOM
        print("\n-- new connection")

    def set_room_id(self, id:int) -> None:
        if not self.rooms.add_client(id, self):
            self.send_message("no")
        else:
            self.room_id = id
            self.send_message("yes")
            self.send_message(self.rooms.get_room_start_time(self.room_id))

    def handle_new_room(self) -> None:
        self.room_id = self.rooms.create_new_room(self)
        self.send_message(str(self.room_id))
        self.rooms.set_room_start_time(self.room_id, self.receive_message())

    def wait_for_room_join(self) -> None:
        player_response = self.receive_message()
        print("\n-- " + player_response)

        if player_response == "new room":
                self.handle_new_room()

        elif player_response.startswith("find room"):
            id_request = int(player_response.split("find room ", 1)[1])
            self.set_room_id(id_request)
    
    def wait_for_start_from_manager(self) -> None:
        self.receive_message()
        
    def remove_client_from_room(self) -> None:
        new_manager = self.rooms.remove_client(self.room_id, self)
        self.update_users_in_room_list(self.room_id)
        self.room_id = Rooms.NOT_CONNECTED_TO_ROOM
        if new_manager is not None:
            new_manager.announce_manager()

    def announce_manager(self) -> None:
        print("\n-- switch manager")
        self.send_message("manager")

    def is_manager(self) -> bool:
        return self.rooms.is_manager(self)

    def run(self):
        while True:
            try:
                self.get_username()
                self.connect_to_room()
                self.handle_waiting_room()
                self.handle_drawing_room()
            except ConnectionError:
                self.remove_client_from_room()
                self.connection.close()
                print("\n-- disconnect")
                break
            except ExitRoomError:
                self.handle_player_exit_room()
    
    def get_username(self) -> None:
        self.name = self.receive_message()

    def handle_drawing_room(self) -> None:
        if self.is_manager():
            secret_word = self.rooms.choose_word_for_round(self.room_id)

            self.send_message(secret_word)
            self.update_drawings_at_guessers()
        else:
            secret_word = self.rooms.get_secret_word(self.room_id)
            self.send_message("clue: " + self.generate_clue(secret_word))
            self.process_guesses()

    def generate_clue(self, input:str) -> str:
        return ' '.join('-' if char.isspace() else '_' for char in input)
    
    def notify_connected_users_changed(self, room_id: int) -> None:
        users_json = self.rooms.get_users_json(room_id)
        self.send_message("users: " + users_json)

    def process_guesses(self) -> None:
        while True:
            guess = self.receive_message()
            if guess.lower().strip() == self.rooms.get_secret_word(self.room_id).lower():
                self.send_message("correct")
    
    def update_drawings_at_guessers(self) -> None:
        while True:
            length, drawing_bytes = self.recvAll()
            if (length > 0):
                drawing_bytes = str(length) + "dataBytes:" + drawing_bytes
                for client in self.rooms.get_room_client_list(self.room_id):
                    if client != self:
                        client.send_message(drawing_bytes)
            
    def handle_waiting_room(self) -> None:
        if self.rooms.is_room_ingame(self.room_id):
            self.send_message("start")
            self.notify_connected_users_changed(self.room_id)
        if self.is_manager():
            self.start_game()
        else:
            self.wait_for_game_beggining()

    def wait_for_game_beggining(self) -> None:
        none_manager_message = self.receive_message() # receive start ok
        if none_manager_message == "manager ok":
            self.start_game()

    def start_game(self) -> None:
        self.wait_for_start_from_manager()
        print("\n-- starting game")
        for client in self.rooms.get_room_client_list(self.room_id):
            client.send_message("start")
        self.update_users_in_room_list(self.room_id)
        self.rooms.set_room_ingame(self.room_id, True)

    def connect_to_room(self) -> None:
        while self.room_id == Rooms.NOT_CONNECTED_TO_ROOM:
            self.wait_for_room_join()
        self.update_users_in_room_list(self.room_id)
        
    def update_users_in_room_list(self, room_id: int) -> None:
        if (self.rooms.room_exists(room_id)):
            for client in self.rooms.get_room_client_list(room_id): 
                client.notify_connected_users_changed(room_id)

    def send_message(self, message: str) -> None:
        self.connection.send((message + "\n").encode())

    def recvAll(self) -> tuple[int, str]:
        drawing_player_response = self.receive_message()

        try:
            length, data = tuple(drawing_player_response.split("dataBytes:", 1))
            length = int(length)
            
            while len(data) < length:
                data += self.receive_message()
            return length, data
        except ValueError:
            return 0, ""

    def receive_message(self) -> str:
        message = self.connection.recv(BUFFER_SIZE).decode()
        if message == "":
            raise ConnectionAbortedError
        elif message == "exit":
            raise ExitRoomError
        else:
            return message

    def __str__(self) -> str:
        return f"ClientThread(ip: {self.ip}, port: {self.port})"
    
    def handle_player_exit_room(self) -> None:
        self.remove_client_from_room()
        self.send_message("exit ok")
        print("\n-- exited room")

class ExitRoomError(Exception):
    pass